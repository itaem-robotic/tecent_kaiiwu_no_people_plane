#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
###########################################################################
# Copyright © 1998 - 2026 Tencent. All Rights Reserved.
###########################################################################
"""
Author: Tencent AI Arena Authors

Drone Delivery feature preprocessor.
智运无人机特征预处理器。
"""

import numpy as np
from agent_ppo.conf.conf import Config


def norm(v, max_v, min_v=0):
    """Normalize v to [0, 1].

    将 v 归一化到 [0, 1]。
    """
    v = np.clip(v, min_v, max_v)
    return (v - min_v) / (max_v - min_v)


def _get_pos_feature(found, cur_pos, target_pos, is_target=False):
    """Compute 7D position feature for a target relative to current position.

    计算目标位置相对于当前位置的 7 维特征。
    """
    relative_pos = (target_pos[0] - cur_pos[0], target_pos[1] - cur_pos[1])
    dist = np.sqrt(relative_pos[0] ** 2 + relative_pos[1] ** 2)
    abs_norm = norm(np.array(target_pos), 128, -128)
    return np.array(
        [
            float(found),
            norm(relative_pos[0] / max(dist, 1e-4), 1, -1),
            norm(relative_pos[1] / max(dist, 1e-4), 1, -1),
            abs_norm[0],
            abs_norm[1],
            norm(dist, 1.41 * 128),
            1.0 if is_target else 0.0,
        ]
    )


class Preprocessor:
    """feature preprocessor for Drone Delivery.

    智运无人机预处理器，仅保留最少信息。
    """

    def __init__(self):
        self.reset()

    def reset(self):
        """Reset all internal state.

        重置所有状态。
        """
        self.cur_pos = (0, 0)
        # 新增：探索奖励相关状态初始化
        self.last_pos = (0, 0)          # 上一帧位置（判断是否原地不动）
        self.prev_action = -1           # 上一步动作（判断重复动作）
        self.continuous_same_act = 0    # 连续重复动作计数

        # Game state / 游戏状态
        self.battery = 100
        self.battery_max = 100
        self.packages = []
        self.delivered = 0
        self.last_delivered = 0
        self.step_no = 0
        # 原有：初始化电量和动作跟踪字段
        self.last_battery = 100
        self.last_action = -1

        # Entities / 实体
        self.stations = []
        self.chargers = []
        self.legal_act = [1]*8

    def _parse_obs(self, env_obs):
        """Parse essential fields from observation dict.

        从 observation 字典中解析必要字段。
        """
        obs = env_obs["observation"]
        frame_state = obs["frame_state"]

        hero = frame_state["heroes"]
        # 新增：先记录上一位置，再更新当前位置（用于计算移动距离）
        self.last_pos = self.cur_pos
        self.cur_pos = (hero["pos"]["x"], hero["pos"]["z"])

        self.battery = hero.get("battery", self.battery_max)
        self.battery_max = hero.get("battery_max", 100)
        self.packages = hero.get("packages", [])

        self.last_delivered = self.delivered
        self.delivered = hero.get("delivered", 0)
        self.step_no = obs.get("step_no", 0)

        self.stations = []
        self.chargers = []
        for organ in frame_state.get("organs", []):
            st = organ.get("sub_type", 0)
            if st == 3:
                self.stations.append(organ)
            if st == 2:
                self.chargers.append(organ)

        self.legal_act = obs.get("legal_action", [1] * 8)

    def feature_process(self, env_obs, last_action):
        """Core feature extraction. Returns (feature_32d, legal_action, reward).

        核心特征提取方法，返回 32 维特征向量、合法动作掩码和奖励。
        """
        self._parse_obs(env_obs)
        self.last_action = last_action

        # 新增：更新连续重复动作计数
        if last_action != -1 and last_action == self.prev_action:
            self.continuous_same_act += 1
        else:
            self.continuous_same_act = 0
        self.prev_action = last_action

        # 1. Hero state features (4D) / 英雄状态特征（4D）
        battery_ratio = norm(self.battery, self.battery_max)
        package_count_norm = norm(len(self.packages), 3)
        cur_pos_norm = norm(np.array(self.cur_pos, dtype=float), 128, -128)
        hero_feat = np.array(
            [
                battery_ratio,
                package_count_norm,
                cur_pos_norm[0],
                cur_pos_norm[1],
            ]
        )

        # 2. Nearest 1 station feature (7D) / 最近 1 个驿站特征（7D）
        target_ids = set(self.packages)

        def station_sort_key(s):
            is_tgt = s.get("config_id", 0) in target_ids
            dist = np.sqrt((s["pos"]["x"] - self.cur_pos[0]) ** 2 + (s["pos"]["z"] - self.cur_pos[1]) ** 2)
            return (0 if is_tgt else 1, dist)

        sorted_stations = sorted(self.stations, key=station_sort_key)

        if len(sorted_stations) > 0:
            s = sorted_stations[0]
            is_target = s.get("config_id", 0) in target_ids
            station_feat = _get_pos_feature(
                True,
                self.cur_pos,
                (s["pos"]["x"], s["pos"]["z"]),
                is_target=is_target,
            )
            target_visible = float(is_target)
        else:
            station_feat = _get_pos_feature(False, self.cur_pos, self.cur_pos, is_target=False)
            target_visible = 0.0

        # 3. Legal action mask (8D) / 合法动作掩码（8D）
        legal_action = self._get_legal_action()

        # 4. Binary indicators (3D) / 二值指示器（3D）
        has_package = 1.0 if len(self.packages) > 0 else 0.0
        battery_low = 1.0 if (self.battery / max(self.battery_max, 1)) < 0.3 else 0.0
        indicators = np.array([has_package, battery_low, target_visible])

        # ====================== 新增：A*相关特征（4维） ======================
        a_star_feat = np.zeros(4)
        try:
            if len(self.packages) > 0 and len(sorted_stations) > 0:
                s = sorted_stations[0]
                tx, tz = s["pos"]["x"], s["pos"]["z"]
                # 获取A*最优动作和路径长度
                best_act = self._a_star_get_next_step(tx, tz)
                path_length = self._a_star_get_path_length(tx, tz)
                
                # 1. A*最优动作编码（0-7归一化到0-1）
                a_star_feat[0] = norm(best_act, 7)
                # 2. A*剩余路径长度（归一化到0-1，最大步数设为200）
                a_star_feat[1] = norm(path_length, 200)
                # 3. A*路径可达性（1=可达，0=不可达）
                a_star_feat[2] = 1.0 if path_length > 0 else 0.0
                # 4. 当前动作与A*最优动作匹配度（1=匹配，0=不匹配）
                a_star_feat[3] = 1.0 if (last_action == best_act and last_action != -1) else 0.0
        except:
            # 异常时特征置0，保证维度固定
            a_star_feat = np.zeros(4)

        # ====================== 新增：充电桩相关特征（6维） ======================
        charger_feat = np.zeros(6)
        try:
            if len(self.chargers) > 0:
                # 排序找到最近充电桩
                def charger_sort_key(c):
                    dist = np.sqrt((c["pos"]["x"] - self.cur_pos[0])**2 + (c["pos"]["z"] - self.cur_pos[1])**2)
                    return dist
                nearest_charger = sorted(self.chargers, key=charger_sort_key)[0]
                c_pos = (nearest_charger["pos"]["x"], nearest_charger["pos"]["z"])
                
                # 1. 最近充电桩相对位置x（归一化到-1~1→0~1）
                max_dist = 1.41 * 128  # 地图对角线最大距离
                rel_x = (c_pos[0] - self.cur_pos[0]) / max_dist
                charger_feat[0] = norm(rel_x, 1, -1)
                # 2. 最近充电桩相对位置z（归一化到-1~1→0~1）
                rel_z = (c_pos[1] - self.cur_pos[1]) / max_dist
                charger_feat[1] = norm(rel_z, 1, -1)
                # 3. 最近充电桩距离（归一化到0~1）
                dist = np.sqrt((c_pos[0]-self.cur_pos[0])**2 + (c_pos[1]-self.cur_pos[1])**2)
                charger_feat[2] = norm(dist, max_dist)
                # 4. 最近充电桩是否可用（1=可用，0=不可用）
                charger_feat[3] = 1.0 if nearest_charger.get("available", 1) else 0.0
                # 5. 当前电量可支撑的最大步数（归一化到0~1）
                step_per_charge = 1  # 每步耗电1，可根据环境调整
                max_support_step = self.battery / step_per_charge
                charger_feat[4] = norm(max_support_step, 200)  # 最大步数200
                # 6. 到目标驿站+返回充电桩的总距离（归一化到0~1）
                if len(sorted_stations) > 0:
                    s_pos = (sorted_stations[0]["pos"]["x"], sorted_stations[0]["pos"]["z"])
                    dist_to_station = np.sqrt((s_pos[0]-self.cur_pos[0])**2 + (s_pos[1]-self.cur_pos[1])**2)
                    dist_station_to_charger = np.sqrt((s_pos[0]-c_pos[0])**2 + (s_pos[1]-c_pos[1])**2)
                    total_dist = dist_to_station + dist_station_to_charger
                    charger_feat[5] = norm(total_dist, 2*max_dist)
        except:
            # 异常时特征置0
            charger_feat = np.zeros(6)

        # ====================== 整合所有特征（22+4+6=32维） ======================
        feature = np.concatenate(
            [
                hero_feat,          # 4D
                station_feat,       # 7D
                np.array(legal_action, dtype=float),  # 8D
                indicators,         # 3D
                a_star_feat,        # 新增4D A*特征
                charger_feat        # 新增6D 充电桩特征
            ]
        )

        reward = self._reward_process()

        return feature, legal_action, reward

    def _get_legal_action(self):
        if hasattr(self, "legal_act") and self.legal_act:
            legal_action = [int(x) for x in self.legal_act[:8]]
        else:
            legal_action = [1] * 8

        if sum(legal_action) == 0:
            return [1] * 8
        return legal_action

    # ====================== A* 避障函数 ======================
    def _dir_to_action(self, dx, dz):
        dir_map = [(-1,-1), (-1,0), (-1,1),
                   (0,-1),          (0,1),
                   (1,-1), (1,0), (1,1)]
        for i, (x, z) in enumerate(dir_map):
            if x == dx and z == dz:
                return i
        return 1

    def _a_star_get_next_step(self, target_x, target_z):
        import heapq
        x, z = self.cur_pos
        gx, gy = int(target_x), int(target_z)
        cx, cy = int(x), int(z)

        if (cx, cy) == (gx, gy):
            return 0

        open_heap = []
        heapq.heappush(open_heap, (0, cx, cy))
        parent = {}
        dirs = [(-1,-1), (-1,0), (-1,1),
                (0,-1),          (0,1),
                (1,-1), (1,0), (1,1)]

        visited = set()
        visited.add((cx, cy))

        while open_heap:
            cost, cx_, cy_ = heapq.heappop(open_heap)
            if (cx_, cy_) == (gx, gy):
                break
            for dx, dz in dirs:
                nx = cx_ + dx
                nz = cy_ + dz
                if (nx, nz) in visited:
                    continue
                act = self._dir_to_action(dx, dz)
                if self.legal_act[act] == 0:
                    continue
                visited.add((nx, nz))
                parent[(nx, nz)] = (cx_, cy_)
                new_cost = cost + 1 + abs(nx - gx) + abs(nz - gy)
                heapq.heappush(open_heap, (new_cost, nx, nz))

        try:
            cur = (gx, gy)
            path = []
            while cur in parent:
                path.append(cur)
                cur = parent[cur]
            path.reverse()
            if len(path) > 0:
                nx, nz = path[0]
                dx = nx - int(x)
                dz = nz - int(z)
                return self._dir_to_action(dx, dz)
        except:
            return 0
        return 0

    def _a_star_get_path_length(self, target_x, target_z):
        """计算从当前位置到目标位置的A*路径总长度（步数）"""
        import heapq
        x, z = self.cur_pos
        gx, gy = int(target_x), int(target_z)
        cx, cy = int(x), int(z)

        # 已到达目标，路径长度为0
        if (cx, cy) == (gx, gy):
            return 0

        open_heap = []
        heapq.heappush(open_heap, (0, cx, cy))
        parent = {}
        dirs = [(-1,-1), (-1,0), (-1,1),
                (0,-1),          (0,1),
                (1,-1), (1,0), (1,1)]

        visited = set()
        visited.add((cx, cy))
        path_length = 0

        while open_heap:
            cost, cx_, cy_ = heapq.heappop(open_heap)
            # 找到目标，回溯计算路径长度
            if (cx_, cy_) == (gx, gy):
                cur = (gx, gy)
                while cur in parent:
                    path_length += 1
                    cur = parent[cur]
                return path_length
            # 遍历所有方向
            for dx, dz in dirs:
                nx = cx_ + dx
                nz = cy_ + dz
                if (nx, nz) in visited:
                    continue
                # 检查动作合法性
                act = self._dir_to_action(dx, dz)
                if self.legal_act[act] == 0:
                    continue
                visited.add((nx, nz))
                parent[(nx, nz)] = (cx_, cy_)
                # A*代价：已走步数 + 曼哈顿距离（启发函数）
                new_cost = cost + 1 + abs(nx - gx) + abs(nz - gy)
                heapq.heappush(open_heap, (new_cost, nx, nz))
        # 目标不可达，返回0
        return 0

    # ====================== 奖励函数（新增探索奖励 + 原有充电/A*奖励） ======================
    def _reward_process(self):
        reward = 0.0
        newly_delivered = max(0, self.delivered - self.last_delivered)
        if newly_delivered > 0:
            reward += 1.0 * newly_delivered

        # 基础步数惩罚（鼓励高效完成）
        reward -= 0.001

        # 1. A* 避障正确方向奖励（原有）
        try:
            if len(self.packages) > 0 and len(self.stations) > 0:
                s = self.stations[0]
                tx, tz = s["pos"]["x"], s["pos"]["z"]
                best_act = self._a_star_get_next_step(tx, tz)
                if self.last_action == best_act:
                    reward += 0.03
        except:
            pass

        # 2. 充电奖励（原有）
        try:
            if hasattr(self, 'last_battery') and self.battery > self.last_battery + 1:
                reward += 0.05
        except:
            pass

        # 3. 新增：探索奖励（核心逻辑）
        try:
            # 3.1 惩罚原地不动：位置未变化则扣奖励（力度大于基础惩罚）
            if self.cur_pos == self.last_pos:
                reward -= 0.08  # 可根据训练效果调整，范围0.05~0.1
            
            # 3.2 惩罚连续重复动作：连续3步以上走同一方向叠加惩罚
            if self.continuous_same_act > 3:
                reward -= 0.02 * self.continuous_same_act  # 惩罚随连续次数递增
            
            # 3.3 鼓励移动探索：移动距离越大，奖励越高（轻微正向激励）
            move_dist = np.sqrt(
                (self.cur_pos[0] - self.last_pos[0])**2 + 
                (self.cur_pos[1] - self.last_pos[1])**2
            )
            if move_dist > 0:
                reward += 0.01 * move_dist  # 移动越远奖励越多，幅度可控
        except:
            pass

        self.last_battery = self.battery
        return [reward]