#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
###########################################################################
# Copyright © 1998 - 2026 Tencent. All Rights Reserved.
###########################################################################
"""
Author: Tencent AI Arena Authors

Drone Delivery PPO configuration.
智运无人机 PPO 配置。
"""


class Config:

    # Feature dimensions / 特征维度
    HERO_STATE_DIM = 4
    STATION_DIM = 7 * 1
    LEGAL_ACT_DIM = 8
    INDICATOR_DIM = 3
    # 新增：A*相关特征维度（4维）
    A_STAR_DIM = 4
    # 新增：充电桩相关特征维度（6维）
    CHARGER_DIM = 6

    # 更新特征列表：加入新增的A*和充电桩维度
    FEATURES = [
        HERO_STATE_DIM,
        STATION_DIM,
        LEGAL_ACT_DIM,
        INDICATOR_DIM,
        A_STAR_DIM,  # 追加A*特征维度
        CHARGER_DIM  # 追加充电桩特征维度
    ]
    # 特征拆分维度（与FEATURES保持一致，用于后续特征切片/解析）
    FEATURE_SPLIT_SHAPE = FEATURES
    # 总特征长度：4+7+8+3+4+6=32
    FEATURE_LEN = sum(FEATURES)
    # 观测维度 = 总特征长度
    DIM_OF_OBSERVATION = FEATURE_LEN

    # Action space / 动作空间
    ACTION_NUM = 8
    LABEL_SIZE_LIST = [ACTION_NUM]
    LEGAL_ACTION_SIZE_LIST = LABEL_SIZE_LIST.copy()

    # Value head (single) / 价值头（单头）
    VALUE_NUM = 1

    # PPO hyperparameters / PPO 超参数
    GAMMA = 0.995
    LAMDA = 0.95
    INIT_LEARNING_RATE_START = 0.0003
    # Moderate entropy coeff / 中等熵系数
    BETA_START = 0.005
    CLIP_PARAM = 0.2
    VF_COEF = 0.5
    GRAD_CLIP_RANGE = 0.5
    USE_GRAD_CLIP = True

    NUMB_HEAD = 1
